import React, { useState, useEffect } from 'react';
import { Heart, Sparkles, Camera, Flower, Flower2 } from 'lucide-react';

function App() {
  const [isVisible, setIsVisible] = useState(false);
  const [currentParagraph, setCurrentParagraph] = useState(0);
  const [showPhotos, setShowPhotos] = useState(false);

  const photos = [
    '/WhatsApp Image 2025-07-17 at 23.00.44.jpeg',
    '/WhatsApp Image 2025-07-18 at 19.29.35 (1).jpeg',
    '/WhatsApp Image 2025-07-18 at 19.29.35 (2).jpeg',
    '/WhatsApp Image 2025-07-18 at 19.29.35 (3).jpeg',
    '/WhatsApp Image 2025-07-18 at 19.29.35 (4).jpeg',
    '/WhatsApp Image 2025-08-28 at 11.12.54.jpeg',
    '/WhatsApp Image 2025-08-28 at 11.05.47.jpeg',
    '/WhatsApp Image 2025-08-14 at 08.55.25.jpeg',
    '/WhatsApp Image 2025-08-23 at 17.10.01.jpeg',
    '/WhatsApp Image 2025-08-23 at 14.59.45.jpeg'
  ];

  const letterText = [
    "Mi amor,",
    "Hoy celebramos un mes más de nuestra historia, y aunque el tiempo a veces parezca pasar volando, para mí cada día contigo es un capítulo único, lleno de recuerdos hermosos que guardo en lo más profundo de mi corazón. Desde que llegaste a mi vida, todo tiene más sentido: el amanecer se siente más brillante, las tardes más dulces y las noches más tranquilas, porque sé que en este camino no estoy solo, te tengo a ti.",
    "Quiero que sepas que tu amor me transforma, me enseña y me inspira. Me inspiras a ser mejor persona, a dejar atrás mis errores y a luchar contra mis debilidades. Porque estar contigo no solo me hace feliz, también me invita a crecer. Y aunque sé que no soy perfecto, quiero prometerte con todas mis fuerzas que siempre trataré de mejorar por nosotros, por nuestro amor y por el futuro que quiero construir a tu lado.",
    "Eres mi alegría, mi refugio y mi motivo de esperanza. Cuando sonríes, siento que el mundo se detiene; cuando me abrazas, siento que todo está bien. Eres la persona con la que quiero compartir mis sueños, mis logros y también mis caídas, porque contigo sé que puedo ser yo mismo sin miedo, sin máscaras, sin dudas.",
    "Gracias por cada palabra de aliento, por cada gesto de cariño, por cada instante en que me haces sentir amado de verdad. Gracias por ser tú, simplemente tú: la mujer increíble que conquistó mi corazón y que cada día lo sigue conquistando.",
    "Hoy celebramos un mes más, pero mi deseo es celebrar muchos más: meses, años y toda una vida juntos. Quiero que este amor no tenga fecha de caducidad, que sea infinito, que siga creciendo con la misma fuerza con la que late mi corazón cada vez que pienso en ti.",
    "Feliz mes, mi vida. Te amo más de lo que las palabras pueden explicar, y siempre, siempre lucharé por ti, por mí, y por nuestro \"nosotros\". ❤️",
    "Con todo mi amor,"
  ];

  useEffect(() => {
    setIsVisible(true);
    const timer = setInterval(() => {
      setCurrentParagraph(prev => {
        if (prev < letterText.length - 1) {
          return prev + 1;
        } else {
          // Show photos after all text is revealed
          setTimeout(() => setShowPhotos(true), 1000);
        }
        clearInterval(timer);
        return prev;
      });
    }, 2000);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 via-pink-50 to-red-50 relative overflow-hidden">
      {/* Floating hearts background */}
      <div className="absolute inset-0 pointer-events-none">
        {[...Array(20)].map((_, i) => (
          <Heart
            key={i}
            className={`absolute text-rose-200 opacity-20 animate-float-${i % 3}`}
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 5}s`,
              fontSize: `${Math.random() * 20 + 10}px`
            }}
          />
        ))}
      </div>

      {/* Sparkles */}
      <div className="absolute inset-0 pointer-events-none">
        {[...Array(15)].map((_, i) => (
          <Sparkles
            key={i}
            className={`absolute text-yellow-300 opacity-30 animate-twinkle`}
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`,
              fontSize: `${Math.random() * 15 + 8}px`
            }}
          />
        ))}
      </div>

      <div className="relative z-10 max-w-4xl mx-auto px-6 py-12">
        {/* Header */}
        <div className={`text-center mb-12 transition-all duration-1000 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-10'}`}>
          <div className="flex items-center justify-center mb-4">
            <Heart className="w-8 h-8 text-rose-500 mr-2 animate-pulse" />
            <h1 className="text-4xl md:text-5xl font-serif text-rose-800 tracking-wide">
              Para Analy
            </h1>
            <Heart className="w-8 h-8 text-rose-500 ml-2 animate-pulse" />
          </div>
          <div className="w-24 h-1 bg-gradient-to-r from-rose-400 to-pink-400 mx-auto rounded-full"></div>
        </div>

        {/* Letter content */}
        <div className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-2xl p-8 md:p-12 border border-rose-100">
          <div className="space-y-6 font-serif text-gray-800 leading-relaxed">
            {letterText.map((paragraph, index) => (
              <div
                key={index}
                className={`transition-all duration-1000 ${
                  index <= currentParagraph 
                    ? 'opacity-100 translate-y-0' 
                    : 'opacity-0 translate-y-4'
                } ${index === 0 ? 'text-2xl font-semibold text-rose-700 mb-8' : ''} ${
                  index === letterText.length - 1 ? 'text-right text-rose-600 font-semibold mt-8' : ''
                }`}
                style={{ 
                  transitionDelay: `${index * 200}ms`,
                  fontSize: index === 0 ? '1.5rem' : '1.1rem',
                  lineHeight: index === 0 ? '1.4' : '1.7'
                }}
              >
                {paragraph}
              </div>
            ))}
          </div>

          {/* Signature area */}
          <div className={`mt-12 text-center transition-all duration-1000 ${
            currentParagraph >= letterText.length - 1 
              ? 'opacity-100 translate-y-0' 
              : 'opacity-0 translate-y-4'
          }`}>
            <div className="flex items-center justify-center space-x-2 text-rose-500">
              <Heart className="w-6 h-6 animate-pulse" />
              <Heart className="w-8 h-8 animate-pulse" style={{ animationDelay: '0.5s' }} />
              <Heart className="w-6 h-6 animate-pulse" style={{ animationDelay: '1s' }} />
            </div>
          </div>
        </div>

        {/* Photo Gallery */}
        <div className={`mt-12 transition-all duration-1000 ${
          showPhotos ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
        }`}>
          <div className="text-center mb-8">
            <div className="flex items-center justify-center mb-4">
              <Camera className="w-6 h-6 text-rose-500 mr-2" />
              <h2 className="text-2xl font-serif text-rose-700">El amor de mi vida se llama Analy</h2>
              <Camera className="w-6 h-6 text-rose-500 ml-2" />
            </div>
            <div className="w-16 h-0.5 bg-gradient-to-r from-rose-400 to-pink-400 mx-auto rounded-full"></div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {photos.map((photo, index) => (
              <div
                key={index}
                className={`relative group overflow-hidden rounded-xl shadow-lg transition-all duration-700 hover:shadow-2xl hover:scale-105 ${
                  showPhotos ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
                }`}
                style={{ 
                  transitionDelay: `${index * 200}ms`,
                  aspectRatio: '4/3'
                }}
              >
                <img
                  src={photo}
                  alt={`Momento especial ${index + 1}`}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <div className="absolute bottom-4 left-4 right-4 text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <p className="text-sm font-serif">Momento {index + 1}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
        {/* Bottom decoration */}
        <div className={`text-center mt-8 transition-all duration-1000 ${
          showPhotos
            ? 'opacity-100 translate-y-0' 
            : 'opacity-0 translate-y-4'
        }`}>
          {/* Animated flowers for Analy */}
          <div className="flex items-center justify-center mb-6 space-x-4">
            {[...Array(7)].map((_, i) => (
              <div
                key={i}
                className={`transition-all duration-1000 ${
                  showPhotos ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
                }`}
                style={{ 
                  transitionDelay: `${i * 300 + 1000}ms`
                }}
              >
                {i % 2 === 0 ? (
                  <Flower 
                    className={`w-8 h-8 text-pink-400 animate-bounce`}
                    style={{ 
                      animationDelay: `${i * 0.5}s`,
                      animationDuration: '2s'
                    }}
                  />
                ) : (
                  <Flower2 
                    className={`w-6 h-6 text-rose-400 animate-pulse`}
                    style={{ 
                      animationDelay: `${i * 0.3}s`,
                      animationDuration: '3s'
                    }}
                  />
                )}
              </div>
            ))}
          </div>
          
          <div className="mb-4">
            <p className="text-2xl font-script text-rose-500 mb-2">
              Para ti, Analy 🌸
            </p>
          </div>
          
          <p className="text-rose-400 font-serif italic">
            "El amor verdadero nunca tiene final"
          </p>
        </div>
      </div>
    </div>
  );
}

export default App;